"""
This subpackage hold anything that is very relevant
to the HTTP ecosystem but not per-say Niquests core logic.
"""
