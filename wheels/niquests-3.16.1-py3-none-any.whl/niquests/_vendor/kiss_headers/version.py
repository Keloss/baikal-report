"""
Expose version
"""

from __future__ import annotations

__version__ = "2.5.0"
VERSION = __version__.split(".")
