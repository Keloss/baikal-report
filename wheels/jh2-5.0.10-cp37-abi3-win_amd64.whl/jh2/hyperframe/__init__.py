"""
hyperframe
~~~~~~~~~~

A module for providing a pure-Python HTTP/2 framing layer.
"""
