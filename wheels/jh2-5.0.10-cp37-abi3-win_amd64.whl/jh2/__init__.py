"""
h2
~~

A HTTP/2 implementation.
"""

from __future__ import annotations

__version__ = "5.0.10"
